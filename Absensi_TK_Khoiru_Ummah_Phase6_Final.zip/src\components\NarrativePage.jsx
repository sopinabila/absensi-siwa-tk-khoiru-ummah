import { useState } from 'react'

export default function NarrativePage({ students, groups, narratives, onSave, onDelete }) {
  const activeStudents = students.filter(student => student.status === 'Aktif')
  const [selectedStudent, setSelectedStudent] = useState(activeStudents[0]?.id || '')
  const [date, setDate] = useState(() => localDate(new Date()))
  const [text, setText] = useState('')
  const [editingId, setEditingId] = useState(null)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const sortedNarratives = [...narratives].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))

  function resetForm() {
    setEditingId(null)
    setText('')
    setDate(localDate(new Date()))
    setSelectedStudent(activeStudents[0]?.id || '')
    setError('')
  }

  function submit(event) {
    event.preventDefault()
    const cleanText = text.trim()
    if (!selectedStudent) { setError('Pilih siswa terlebih dahulu.'); return }
    if (cleanText.length < 10) { setError('Isi narasi minimal 10 karakter agar catatan jelas.'); return }
    const record = { studentId: selectedStudent, date, text: cleanText, updatedAt: new Date().toISOString() }
    onSave(record, editingId)
    resetForm()
    setNotice(editingId ? 'Narasi diperbarui di sesi demo.' : 'Narasi disimpan di sesi demo.')
  }

  function edit(item) {
    setEditingId(item.id)
    setSelectedStudent(item.studentId)
    setDate(item.date)
    setText(item.text)
    setError('')
    setNotice('')
    document.getElementById('narrative-form-title')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  function remove(item) {
    const student = students.find(entry => entry.id === item.studentId)
    if (!window.confirm(`Hapus catatan narasi untuk ${student?.name || 'siswa ini'} dari sesi demo?`)) return
    onDelete(item.id)
    if (editingId === item.id) resetForm()
    setNotice('Catatan narasi dihapus dari sesi demo.')
  }

  return <div className="narrative-page"><div className="page-heading"><div><div className="eyebrow green-eyebrow">CATATAN SISWA · DEMO</div><h1>Narasi Perkembangan</h1><p>Tulis catatan perkembangan siswa dengan bahasa yang jelas dan suportif.</p></div><span className="local-chip"><i/>Lokal sesi ini</span></div>
    <div className="narrative-disclaimer"><span>ⓘ</span><p>Gunakan ruang ini untuk catatan perkembangan umum. Narasi demo bukan penilaian klinis atau diagnostik.</p></div>
    {notice && <div className="inline-notice" role="status"><span>i</span>{notice}<button aria-label="Tutup pemberitahuan" onClick={() => setNotice('')}>×</button></div>}
    <div className="narrative-layout"><section className="panel narrative-form-panel"><div className="narrative-panel-heading"><div><span className="eyebrow green-eyebrow">FORM NARASI</span><h2 id="narrative-form-title">{editingId ? 'Ubah catatan' : 'Catatan baru'}</h2></div><span className="narrative-form-symbol">✎</span></div>
      {activeStudents.length === 0 ? <div className="master-empty"><div className="empty-mark">＋</div><h3>Belum ada siswa aktif</h3><p>Tambahkan siswa aktif pada menu Data Siswa.</p></div> : <form className="narrative-form" onSubmit={submit} noValidate><label htmlFor="narrative-student">Nama siswa<span>*</span></label><select id="narrative-student" value={selectedStudent} onChange={event => setSelectedStudent(event.target.value)}>{activeStudents.map(student => <option key={student.id} value={student.id}>{student.name} · {groups.find(group => group.id === student.groupId)?.name || 'Kelompok belum ditetapkan'}</option>)}</select><label htmlFor="narrative-date">Tanggal catatan<span>*</span></label><input id="narrative-date" type="date" value={date} onChange={event => { if (event.target.value) setDate(event.target.value) }}/><label htmlFor="narrative-text">Narasi perkembangan<span>*</span></label><textarea id="narrative-text" rows="6" maxLength="800" value={text} onChange={event => setText(event.target.value)} placeholder="Tuliskan pengamatan perkembangan dengan kalimat yang spesifik dan suportif…"/><div className="narrative-length">{text.length}/800 karakter</div>{error && <p className="form-error" role="alert">{error}</p>}<div className="narrative-form-actions">{editingId && <button type="button" className="cancel-btn" onClick={resetForm}>Batal ubah</button>}<button className="primary-btn" type="submit">{editingId ? 'Simpan perubahan' : 'Simpan narasi'}</button></div><p className="narrative-local-note">Perubahan hanya berlaku di sesi demo.</p></form>}
    </section>
    <section className="panel narrative-list-panel"><div className="narrative-panel-heading"><div><span className="eyebrow green-eyebrow">RIWAYAT SESI INI</span><h2>Catatan tersimpan</h2></div><span className="record-count">{narratives.length} catatan</span></div>{sortedNarratives.length === 0 ? <div className="narrative-empty"><div className="empty-mark">✎</div><h3>Belum ada catatan</h3><p>Catatan yang disimpan akan tampil di sini selama sesi demo.</p></div> : <div className="narrative-list">{sortedNarratives.map(item => { const student = students.find(entry => entry.id === item.studentId); return <article className="narrative-item" key={item.id}><div className="narrative-item-top"><div className="narrative-student"><span className={`student-avatar ${student?.tone || 'mint'}`}>{student?.initials || 'S'}</span><span><strong>{student?.name || 'Siswa tidak tersedia'}</strong><small>{groups.find(group => group.id === student?.groupId)?.name || 'Kelompok tidak tersedia'}</small></span></div><time dateTime={item.date}>{formatDate(item.date)}</time></div><p>{item.text}</p><div className="narrative-item-actions"><button onClick={() => edit(item)}>Ubah</button><button className="delete-row" onClick={() => remove(item)}>Hapus</button></div></article> })}</div>}</section></div>
  </div>
}

function localDate(date) { return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}` }
function formatDate(date) { return new Intl.DateTimeFormat('id-ID', { day: 'numeric', month: 'short', year: 'numeric' }).format(new Date(`${date}T12:00:00`)) }
