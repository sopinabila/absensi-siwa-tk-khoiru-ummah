import { useMemo, useState } from 'react'

const statuses = ['Hadir', 'Izin', 'Sakit', 'Alpa']

export default function AttendanceRecapPage({ students, groups, teachers, attendance, year, semester }) {
  const [view, setView] = useState('siswa')
  const [groupFilter, setGroupFilter] = useState('all')
  const [search, setSearch] = useState('')
  const activeStudents = students.filter(student => student.status === 'Aktif' && (groupFilter === 'all' || student.groupId === groupFilter))
  const periodRecords = attendance.filter(item => item.year === year && item.semester === semester && activeStudents.some(student => student.id === item.studentId))
  const studentRows = useMemo(() => activeStudents.map(student => {
    const history = periodRecords.filter(item => item.studentId === student.id)
    const counts = Object.fromEntries(statuses.map(status => [status, history.filter(item => item.status === status).length]))
    const total = history.length
    return { student, counts, total, percent: total ? Math.round(counts.Hadir / total * 100) : 0 }
  }), [activeStudents, periodRecords])
  const filteredStudents = studentRows.filter(row => row.student.name.toLowerCase().includes(search.toLowerCase().trim()))
  const groupRows = groups.filter(group => groupFilter === 'all' || group.id === groupFilter).filter(group => group.name.toLowerCase().includes(search.toLowerCase().trim())).map(group => {
    const members = studentRows.filter(row => row.student.groupId === group.id)
    const counts = Object.fromEntries(statuses.map(status => [status, members.reduce((total, row) => total + row.counts[status], 0)]))
    const total = members.reduce((sum, row) => sum + row.total, 0)
    const present = counts.Hadir
    return { group, members: members.length, counts, total, percent: total ? Math.round(present / total * 100) : 0, teacher: teachers.find(teacher => teacher.id === group.teacherId)?.name || 'Belum ditetapkan' }
  })
  const overall = Object.fromEntries(statuses.map(status => [status, periodRecords.filter(item => item.status === status).length]))
  const overallTotal = statuses.reduce((sum, status) => sum + overall[status], 0)
  const overallPercent = overallTotal ? Math.round(overall.Hadir / overallTotal * 100) : 0
  const displayedCount = view === 'siswa' ? filteredStudents.length : groupRows.length

  return <div className="recap-page"><div className="page-heading"><div><div className="eyebrow green-eyebrow">REKAPITULASI · DATA DEMO</div><h1>Rekapitulasi Absensi</h1><p>Ringkasan kehadiran per siswa atau kelompok pada periode aktif.</p></div><span className="local-chip"><i/>Semester {semester} · {year}</span></div>
    <section className="recap-summary-grid"><article className="recap-kpi"><span>Total catatan</span><strong>{overallTotal}</strong><small>status absensi tersimpan di demo</small></article><article className="recap-kpi"><span>Hadir</span><strong>{overall.Hadir}</strong><small>dari {overallTotal} catatan periode</small></article><article className="recap-kpi"><span>Persentase kehadiran</span><strong>{overallPercent}<small>%</small></strong><small>Hadir ÷ seluruh status tercatat</small></article><article className="recap-kpi"><span>Siswa aktif</span><strong>{activeStudents.length}</strong><small>sesuai filter kelompok</small></article></section>
    <section className="panel recap-panel"><div className="recap-toolbar"><div className="recap-tabs" role="tablist" aria-label="Tampilan rekap"><button role="tab" aria-selected={view === 'siswa'} className={view === 'siswa' ? 'selected' : ''} onClick={() => setView('siswa')}>Per siswa</button><button role="tab" aria-selected={view === 'kelompok'} className={view === 'kelompok' ? 'selected' : ''} onClick={() => setView('kelompok')}>Per kelompok</button></div><div className="recap-filters"><label className="recap-search"><span>Cari</span><input type="search" value={search} onChange={event => setSearch(event.target.value)} placeholder={view === 'siswa' ? 'Nama siswa' : 'Nama kelompok'}/></label><label className="recap-group-filter"><span>Kelompok</span><select value={groupFilter} onChange={event => setGroupFilter(event.target.value)}><option value="all">Semua kelompok</option>{groups.map(group => <option key={group.id} value={group.id}>{group.name}</option>)}</select></label></div></div>
      <div className="recap-table-heading"><div><h2>{view === 'siswa' ? 'Kehadiran per siswa' : 'Kehadiran per kelompok'}</h2><p>Persentase dihitung dari status yang tercatat pada periode ini.</p></div><span>{displayedCount} {view === 'siswa' ? 'siswa' : 'kelompok'}</span></div>
      {displayedCount === 0 ? <div className="master-empty"><div className="empty-mark">⌕</div><h3>Tidak ada data rekap</h3><p>Ubah kata pencarian atau filter kelompok.</p></div> : <div className="table-wrap recap-table-wrap">{view === 'siswa' ? <table className="recap-table"><thead><tr><th>SISWA</th><th>KELOMPOK</th><th>HADIR</th><th>IZIN</th><th>SAKIT</th><th>ALPA</th><th>PERSENTASE HADIR</th></tr></thead><tbody>{filteredStudents.map(({ student, counts, total, percent }) => <tr key={student.id}><td><div className="master-person"><span className={`student-avatar ${student.tone || 'mint'}`}>{student.initials}</span><span><strong>{student.name}</strong><small>{total} catatan</small></span></div></td><td>{groups.find(group => group.id === student.groupId)?.name || 'Belum ditetapkan'}</td>{statuses.map(status => <td key={status}>{counts[status]}</td>)}<td><Progress percent={percent}/></td></tr>)}</tbody></table> : <table className="recap-table"><thead><tr><th>KELOMPOK</th><th>GURU PENDAMPING</th><th>JUMLAH SISWA</th><th>HADIR</th><th>IZIN</th><th>SAKIT</th><th>ALPA</th><th>PERSENTASE HADIR</th></tr></thead><tbody>{groupRows.map(({ group, members, counts, total, percent, teacher }) => <tr key={group.id}><td><strong>{group.name}</strong><small className="cell-subtext">{total} catatan</small></td><td>{teacher}</td><td>{members}</td>{statuses.map(status => <td key={status}>{counts[status]}</td>)}<td><Progress percent={percent}/></td></tr>)}</tbody></table>}</div>}
      <div className="recap-footnote"><span>ⓘ</span>Persentase hadir = jumlah status Hadir dibagi seluruh status yang sudah tercatat. Data belum diisi tidak masuk perhitungan.</div>
    </section>
  </div>
}

function Progress({ percent }) { return <div className="recap-progress-cell"><div className="recap-progress" aria-label={`${percent}% hadir`}><i style={{ width: `${percent}%` }}/></div><strong>{percent}%</strong></div> }
