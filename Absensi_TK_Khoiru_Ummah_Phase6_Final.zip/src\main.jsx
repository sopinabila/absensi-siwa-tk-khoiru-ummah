import React from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.jsx'
import './styles.css'
import './styles-phase3.css'
import './styles-phase4.css'
import './styles-phase5.css'

createRoot(document.getElementById('root')).render(<React.StrictMode><App /></React.StrictMode>)
