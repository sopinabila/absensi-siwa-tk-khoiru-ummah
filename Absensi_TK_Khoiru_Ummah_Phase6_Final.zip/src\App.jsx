import { useState } from 'react'
import { academicYears, initialAttendance, initialGroups, initialStudents, initialTeachers, menuGroups, semesters } from './data/demoData.js'
import DashboardPage from './components/DashboardPage.jsx'
import AcademicPeriodPage from './components/AcademicPeriodPage.jsx'
import MasterDataPage from './components/MasterDataPage.jsx'
import AttendancePage from './components/AttendancePage.jsx'
import AttendanceRecapPage from './components/AttendanceRecapPage.jsx'
import NarrativePage from './components/NarrativePage.jsx'
import ReportPage from './components/ReportPage.jsx'

const paths = {
  grid: <><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></>,
  users: <><path d="M16 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="10" cy="7" r="4"/><path d="M20 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></>,
  teacher: <><path d="M3 21h18M5 21V7l8-4v18M19 21V11l-6-4"/><path d="M9 9v.01M9 12v.01M9 15v.01M9 18v.01"/></>,
  layers: <><path d="m12 2 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5M3 17l9 5 9-5"/></>,
  calendar: <><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 11h18"/></>,
  check: <><path d="M9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></>,
  chart: <><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-5 5"/></>,
  note: <><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6M8 13h8M8 17h8"/></>,
  file: <><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6M8 13h8M8 17h5"/></>,
  search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
  bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></>,
  chevron: <path d="m9 18 6-6-6-6"/>,
  logout: <><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5M21 12H9"/></>,
}

function Icon({ name, size = 19 }) {
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">{paths[name]}</svg>
}

function Login({ onLogin }) {
  const [email, setEmail] = useState('admin@demo.sch.id')
  const [password, setPassword] = useState('demo1234')
  const [role, setRole] = useState('Admin')
  const [error, setError] = useState('')
  function submit(event) {
    event.preventDefault()
    if (!email.includes('@') || password.trim().length < 4) { setError('Masukkan email yang valid dan kata sandi minimal 4 karakter.'); return }
    onLogin({ name: role === 'Guru' ? 'Aisyah Rahmawati' : role === 'Pimpinan' ? 'Bunda Khadijah' : 'Admin Demo', role })
  }
  return <main className="login-page">
    <section className="login-art"><div className="login-brand"><Brand /></div><div className="login-art-copy"><span className="eyebrow">RUANG TUMBUH GENERASI QURANI</span><h1>Hadir hari ini,<br/><em>bertumbuh</em> setiap hari.</h1><p>Kelola kehadiran dan perkembangan siswa dalam satu ruang yang hangat dan terarah.</p><div className="art-orbit orbit-one"/><div className="art-orbit orbit-two"/><div className="art-badge"><span>✳</span> Belajar · Tumbuh · Menginspirasi</div></div><div className="login-art-footer">TAHFIZH PLUS KHOIRU UMMAH · TK BOGOR UTARA</div></section>
    <section className="login-form-side"><form className="login-card" onSubmit={submit}><div className="mobile-brand"><Brand /></div><span className="eyebrow green-eyebrow">SELAMAT DATANG KEMBALI</span><h2>Masuk ke akun demo</h2><p className="form-subtitle">Gunakan akses demo untuk menjelajahi prototipe.</p>
      <label htmlFor="email">Email</label><input id="email" type="email" value={email} onChange={e => setEmail(e.target.value)} autoComplete="username" required />
      <label htmlFor="password">Kata sandi</label><input id="password" type="password" value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password" required minLength="4" />
      <label htmlFor="role">Masuk sebagai</label><select id="role" value={role} onChange={e => setRole(e.target.value)}><option>Admin</option><option>Guru</option><option>Pimpinan</option></select>
      {error && <p className="form-error" role="alert">{error}</p>}<button className="primary-btn login-submit" type="submit">Masuk ke dashboard <span>→</span></button><div className="demo-hint"><span className="hint-icon">i</span><span>Akun demo · Data ilustrasi lokal<br/><small>Sesi ini hanya simulasi, bukan autentikasi produksi.</small></span></div>
      <p className="login-copyright">© 2025 Tahfizh Plus Khoiru Ummah · Prototipe</p></form></section>
  </main>
}

function Brand({ compact = false }) {
  return <div className="brand"><div className="brand-mark"><span>k</span></div>{!compact && <div className="brand-text"><strong>Khoiru Ummah</strong><small>ABSENSI SISWA · TK BOGOR UTARA</small></div>}</div>
}

function Sidebar({ active, setActive, collapsed, setCollapsed, mobileOpen, setMobileOpen, onLogout, user, allowedMenus = menuGroups }) {
  return <><div className={`mobile-scrim ${mobileOpen ? 'show' : ''}`} onClick={() => setMobileOpen(false)} /><aside className={`sidebar ${collapsed ? 'collapsed' : ''} ${mobileOpen ? 'mobile-open' : ''}`}>
    <div className="sidebar-top"><Brand compact={collapsed}/><button className="collapse-btn" onClick={() => setCollapsed(!collapsed)} aria-label={collapsed ? 'Buka sidebar' : 'Ciutkan sidebar'}><span>‹</span></button><button className="mobile-close" onClick={() => setMobileOpen(false)} aria-label="Tutup menu">×</button></div>
    {!collapsed && <div className="workspace-switch"><div className="workspace-logo">K</div><div><strong>TK Bogor Utara</strong><small>Unit pendidikan</small></div><span className="workspace-dots">···</span></div>}
    <nav className="side-nav" aria-label="Navigasi utama">{allowedMenus.map(group => <div className="nav-group" key={group.label}><div className="nav-label">{!collapsed && group.label}</div>{group.items.map(item => <button key={item.id} title={collapsed ? item.label : undefined} className={`nav-item ${active === item.id ? 'active' : ''}`} onClick={() => { setActive(item.id); setMobileOpen(false) }}><Icon name={item.icon}/>{!collapsed && <><span>{item.label}</span>{item.id === 'absensi' && <i className="nav-dot"/>}</>}</button>)}</div>)}</nav>
    {!collapsed && <div className="sidebar-bottom"><div className="help-card"><div className="help-icon">✳</div><strong>Butuh bantuan?</strong><p>Jelajahi menu demo untuk melihat gambaran aplikasi.</p><button onClick={() => setActive('dashboard')}>Kembali ke beranda <span>→</span></button></div><div className="sidebar-user"><div className="avatar avatar-green">{user.name.split(' ').map(x => x[0]).slice(0,2).join('')}</div><div className="user-info"><strong>{user.name}</strong><small>{user.role} · Akun demo</small></div><button aria-label="Keluar dari akun demo" title="Keluar" onClick={onLogout}><Icon name="logout" size={17}/></button></div></div>}
  </aside></>
}

const pageInfo = {
  siswa: ['Data Siswa', 'Kelola data siswa aktif di lingkungan sekolah.', '128 siswa terdaftar'], guru: ['Data Guru', 'Informasi guru dan pendamping kelompok belajar.', '12 guru aktif'], kelompok: ['Kelompok Kelas', 'Kelompok belajar dan guru pendamping.', '4 kelompok demo'], periode: ['Tahun Ajaran & Semester', 'Periode akademik yang digunakan pada prototipe.', '2024/2025 · Semester Genap'], absensi: ['Absensi Harian', 'Pencatatan kehadiran harian siswa.', 'Data ilustrasi · 18 Mei 2025'], rekap: ['Rekapitulasi Absensi', 'Ringkasan kehadiran siswa berdasarkan periode.', 'Semester Genap 2024/2025'], narasi: ['Narasi Perkembangan', 'Catatan perkembangan siswa untuk sesi demo.', 'Form akan tersedia pada fase berikutnya'], laporan: ['Laporan PDF', 'Pratinjau laporan kehadiran sekolah.', 'Fitur laporan direncanakan pada fase berikutnya'],
}

function Placeholder({ page, navigate }) {
  const [title, description, meta] = pageInfo[page] || pageInfo.siswa
  return <div className="placeholder-wrap"><div className="page-heading"><div><div className="eyebrow green-eyebrow">AREA DEMO</div><h1>{title}</h1><p>{description}</p></div><span className="outline-btn read-only-badge">Pratinjau fase 2</span></div><div className="placeholder-card"><div className="placeholder-art"><div className="placeholder-icon"><Icon name={menuGroups.flatMap(g => g.items).find(i => i.id === page)?.icon || 'grid'} size={28}/></div><span className="placeholder-orbit orbit-a"/><span className="placeholder-orbit orbit-b"/></div><span className="eyebrow green-eyebrow">FONDASI NAVIGASI SIAP</span><h2>{meta}</h2><p>Menu dan tata letak ini sudah tersedia untuk menunjukkan struktur aplikasi. Isi dan interaksi lengkap dijadwalkan pada fase implementasi berikutnya.</p><div className="placeholder-actions"><button className="primary-btn" onClick={() => navigate('dashboard')}>Kembali ke dashboard <Icon name="chevron" size={16}/></button><span className="local-only"><i/>Data demo · Tidak tersimpan permanen</span></div></div></div>
}

function AppShell({ user, onLogout }) {
  const [active, setActive] = useState('dashboard')
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [userMenu, setUserMenu] = useState(false)
  const [students, setStudents] = useState(initialStudents)
  const [teachers, setTeachers] = useState(initialTeachers)
  const [groups, setGroups] = useState(initialGroups)
  const [attendance, setAttendance] = useState(initialAttendance)
  const [narratives, setNarratives] = useState([])
  const [period, setPeriod] = useState({ year: '2026/2027', semester: 'Ganjil' })
  const roleMenus = user.role === 'Guru'
    ? [{ label: 'MENU GURU', items: menuGroups.flatMap(group => group.items).filter(item => ['dashboard', 'absensi', 'narasi'].includes(item.id)) }]
    : user.role === 'Pimpinan'
      ? [{ label: 'MENU PIMPINAN', items: menuGroups.flatMap(group => group.items).filter(item => ['dashboard', 'rekap', 'laporan'].includes(item.id)) }]
      : menuGroups
  const allowedPages = new Set(roleMenus.flatMap(group => group.items.map(item => item.id)))
  const assignedTeacher = user.role === 'Guru' ? teachers.find(teacher => teacher.name === user.name) : null
  const scopedGroups = user.role === 'Guru' ? groups.filter(group => group.teacherId === assignedTeacher?.id) : groups
  const scopedStudents = user.role === 'Guru' ? students.filter(student => scopedGroups.some(group => group.id === student.groupId)) : students
  const scopedTeachers = user.role === 'Guru' ? teachers.filter(teacher => teacher.id === assignedTeacher?.id) : teachers
  const pageNames = { dashboard: 'Dashboard', siswa: 'Data Siswa', guru: 'Data Guru', kelompok: 'Kelompok Kelas', periode: 'Tahun Ajaran & Semester' }
  const title = pageNames[active] || pageInfo[active]?.[0] || 'Dashboard'
  function navigate(id) { setActive(allowedPages.has(id) ? id : 'dashboard'); setMobileOpen(false) }
  function saveRecord(type, fields, id) {
    const setRecords = type === 'siswa' ? setStudents : type === 'guru' ? setTeachers : setGroups
    if (id) setRecords(current => current.map(record => record.id === id ? { ...record, ...fields, ...(fields.name ? { initials: fields.name.split(' ').slice(0, 2).map(part => part[0]).join('') } : {}) } : record))
    else {
      const prefix = type === 'siswa' ? 'S' : type === 'guru' ? 'G' : 'K'
      const record = { ...fields, id: `${prefix}-${Date.now().toString().slice(-6)}`, ...(type !== 'kelompok' ? { initials: fields.name.split(' ').slice(0, 2).map(part => part[0]).join(''), tone: 'mint' } : {}) }
      if (type === 'siswa') setRecords(current => [...current, { ...record, attendance: 'Hadir' }])
      else setRecords(current => [...current, record])
      if (type === 'guru') {
        const previousTeacherId = groups.find(group => group.id === fields.groupId)?.teacherId
        setGroups(current => current.map(group => group.id === fields.groupId ? { ...group, teacherId: record.id } : group))
        if (previousTeacherId) setTeachers(current => current.map(teacher => teacher.id === previousTeacherId ? { ...teacher, groupId: '' } : teacher))
      }
      if (type === 'kelompok') {
        const previousTeacherId = groups.find(group => group.id === record.id)?.teacherId
        setTeachers(current => current.map(teacher => teacher.id === fields.teacherId ? { ...teacher, groupId: record.id } : teacher.id === previousTeacherId ? { ...teacher, groupId: '' } : teacher))
      }
    }
    if (type === 'guru' && id) setGroups(current => current.map(group => group.teacherId === id ? { ...group, teacherId: group.id === fields.groupId ? id : '' } : group.id === fields.groupId ? { ...group, teacherId: id } : group))
    if (type === 'kelompok' && id) {
      const previousTeacherId = groups.find(group => group.id === id)?.teacherId
      setTeachers(current => current.map(teacher => teacher.id === fields.teacherId ? { ...teacher, groupId: id } : teacher.id === previousTeacherId ? { ...teacher, groupId: '' } : teacher))
    }
    return { ok: true }
  }
  function deleteRecord(type, id) {
    const setRecords = type === 'siswa' ? setStudents : type === 'guru' ? setTeachers : setGroups
    setRecords(current => current.filter(record => record.id !== id))
    if (type === 'kelompok') setTeachers(current => current.map(teacher => teacher.groupId === id ? { ...teacher, groupId: '' } : teacher))
  }
  function saveAttendance(date, entries, year, semester) {
    setAttendance(current => {
      const next = [...current]
      entries.forEach(entry => {
        const id = `${date}-${entry.studentId}`
        const record = { ...entry, id, date, year, semester }
        const index = next.findIndex(item => item.id === id)
        if (index === -1) next.push(record)
        else next[index] = record
      })
      return next
    })
  }
  function saveNarrative(record, id) {
    if (id) setNarratives(current => current.map(item => item.id === id ? { ...item, ...record, id } : item))
    else setNarratives(current => [...current, { ...record, id: `N-${Date.now().toString().slice(-7)}` }])
  }
  return <div className={`app-shell ${collapsed ? 'sidebar-collapsed' : ''}`}><Sidebar active={active} setActive={navigate} collapsed={collapsed} setCollapsed={setCollapsed} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} onLogout={onLogout} user={user} allowedMenus={roleMenus}/><main className="main-area"><header className="topbar"><div className="topbar-left"><button className="mobile-menu-btn" aria-label="Buka menu" onClick={() => setMobileOpen(true)}><span/><span/><span/></button><div className="breadcrumb">Beranda <Icon name="chevron" size={13}/> <strong>{title}</strong></div></div><div className="topbar-right"><label className="topbar-period-label" htmlFor="header-period">Periode</label><select id="header-period" className="topbar-period-select" aria-label="Pilih tahun ajaran dan semester" disabled={user.role !== 'Admin'} value={`${period.year}|${period.semester}`} onChange={event => { const [year, semester] = event.target.value.split('|'); setPeriod({ year, semester }) }}>{academicYears.map(year => semesters.map(semester => <option key={`${year}-${semester}`} value={`${year}|${semester}`}>{year} · {semester}</option>))}</select><button className="icon-btn notification-btn" aria-label="Notifikasi demo" title="Notifikasi demo" onClick={() => window.alert('Notifikasi demo: belum ada pemberitahuan baru.')}><Icon name="bell"/><i/></button><div className="topbar-separator"/><div className="user-menu-wrap"><button className="topbar-user" onClick={() => setUserMenu(!userMenu)} aria-expanded={userMenu}><span className="avatar avatar-green">{user.name.split(' ').map(x => x[0]).slice(0,2).join('')}</span><span className="topbar-user-text"><strong>{user.name}</strong><small>{user.role} · Demo</small></span><span className="down-caret">⌄</span></button>{userMenu && <div className="user-dropdown"><strong>{user.name}</strong><small>Sesi akun simulasi</small><button onClick={() => { setUserMenu(false); onLogout() }}><Icon name="logout" size={16}/> Keluar dari akun demo</button></div>}</div></div></header><div className="content"><div className="content-inner">{active === 'dashboard' ? <DashboardPage user={user} students={scopedStudents} teachers={scopedTeachers} groups={scopedGroups} period={period} attendance={attendance} navigate={navigate}/> : !allowedPages.has(active) ? <Placeholder page={active} navigate={navigate}/> : ['siswa', 'guru', 'kelompok'].includes(active) ? <MasterDataPage key={active} type={active} records={active === 'siswa' ? students : active === 'guru' ? teachers : groups} students={students} teachers={teachers} groups={groups} onSave={saveRecord} onDelete={deleteRecord}/> : active === 'periode' ? <AcademicPeriodPage period={period} setPeriod={setPeriod} years={academicYears} semesters={semesters}/> : active === 'absensi' ? <AttendancePage students={scopedStudents} groups={scopedGroups} attendance={attendance} onSave={saveAttendance} year={period.year} semester={period.semester}/> : active === 'rekap' ? <AttendanceRecapPage students={students} groups={groups} teachers={teachers} attendance={attendance} year={period.year} semester={period.semester}/> : active === 'narasi' ? <NarrativePage students={scopedStudents} groups={scopedGroups} narratives={narratives.filter(item => scopedStudents.some(student => student.id === item.studentId))} onSave={saveNarrative} onDelete={id => setNarratives(current => current.filter(item => item.id !== id))}/> : active === 'laporan' ? <ReportPage students={students} groups={groups} attendance={attendance} year={period.year} semester={period.semester}/> : <Placeholder page={active} navigate={navigate}/>}</div></div></main></div>
}

export default function App() {
  const [user, setUser] = useState(null)
  return user ? <AppShell user={user} onLogout={() => setUser(null)}/> : <Login onLogin={setUser}/>
}

