import { useMemo, useState } from 'react'

const attendanceStatuses = ['Hadir', 'Izin', 'Sakit', 'Alpa']

export default function AttendancePage({ students, groups, attendance, onSave, year, semester }) {
  const [date, setDate] = useState(() => localDate(new Date()))
  const [groupId, setGroupId] = useState('all')
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [changes, setChanges] = useState({})
  const [notice, setNotice] = useState('')
  const dateAttendance = useMemo(() => Object.fromEntries(attendance.filter(item => item.date === date).map(item => [item.studentId, item.status])), [attendance, date])
  const activeStudents = students.filter(student => student.status === 'Aktif')
  const matchingStudents = activeStudents.filter(student => {
    const status = changes[student.id] || dateAttendance[student.id] || 'Belum diisi'
    return (groupId === 'all' || student.groupId === groupId)
      && student.name.toLowerCase().includes(search.toLowerCase().trim())
  })
  const visibleStudents = matchingStudents.filter(student => (statusFilter === 'all' || (changes[student.id] || dateAttendance[student.id] || 'Belum diisi') === statusFilter))
  const dateLabel = new Intl.DateTimeFormat('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(`${date}T12:00:00`))
  const statusCounts = attendanceStatuses.reduce((result, status) => {
    result[status] = matchingStudents.filter(student => (changes[student.id] || dateAttendance[student.id]) === status).length
    return result
  }, {})
  const changeCount = Object.keys(changes).length

  function changeDate(value) { if (!value) return; setDate(value); setChanges({}); setNotice('') }
  function changeStatus(studentId, value) {
    const existing = dateAttendance[studentId]
    setChanges(current => {
      const next = { ...current }
      if (value === existing || value === 'Belum diisi' && !existing) delete next[studentId]
      else next[studentId] = value
      return next
    })
    setNotice('')
  }
  function markVisible(status) {
    setChanges(current => {
      const next = { ...current }
      visibleStudents.forEach(student => {
        if (dateAttendance[student.id] === status) delete next[student.id]
        else next[student.id] = status
      })
      return next
    })
    setNotice(`${visibleStudents.length} siswa yang tampil ditandai ${status.toLowerCase()}. Simpan untuk menerapkan.`)
  }
  function save() {
    const entries = Object.entries(changes).map(([studentId, status]) => ({ studentId, status }))
    if (!entries.length) return
    onSave(date, entries, year, semester)
    setChanges({})
    setNotice(`Absensi ${dateLabel} berhasil disimpan di sesi demo.`)
  }

  return <div className="attendance-page">
    <div className="page-heading"><div><div className="eyebrow green-eyebrow">PENCATATAN · DATA DEMO</div><h1>Absensi Harian</h1><p>Pilih tanggal dan kelompok, lalu catat status kehadiran siswa.</p></div><span className="local-chip"><i/>Tidak tersimpan permanen</span></div>
    <div className="attendance-summary-grid"><SummaryCard label="Hadir" count={statusCounts.Hadir || 0} tone="present"/><SummaryCard label="Izin" count={statusCounts.Izin || 0} tone="permission"/><SummaryCard label="Sakit" count={statusCounts.Sakit || 0} tone="sick"/><SummaryCard label="Alpa" count={statusCounts.Alpa || 0} tone="absent"/></div>
    <section className="panel attendance-controls"><div className="attendance-filter-fields"><div className="attendance-field"><label htmlFor="attendance-date">Tanggal</label><input id="attendance-date" type="date" value={date} onChange={event => changeDate(event.target.value)}/></div><div className="attendance-field"><label htmlFor="attendance-group">Kelompok</label><select id="attendance-group" value={groupId} onChange={event => setGroupId(event.target.value)}><option value="all">Semua kelompok</option>{groups.map(group => <option key={group.id} value={group.id}>{group.name}</option>)}</select></div><div className="attendance-field attendance-search"><label htmlFor="attendance-search">Cari siswa</label><input id="attendance-search" type="search" value={search} onChange={event => setSearch(event.target.value)} placeholder="Ketik nama siswa"/></div><div className="attendance-field"><label htmlFor="attendance-status-filter">Status</label><select id="attendance-status-filter" value={statusFilter} onChange={event => setStatusFilter(event.target.value)}><option value="all">Semua status</option>{attendanceStatuses.map(status => <option key={status}>{status}</option>)}<option>Belum diisi</option></select></div></div><div className="attendance-toolbar"><div><span className="attendance-date-title">{dateLabel}</span><span className="attendance-period">Semester {semester} · {year}</span></div><div className="attendance-actions"><button className="secondary-btn" onClick={() => markVisible('Hadir')} disabled={!visibleStudents.length}>Tandai yang tampil hadir</button><button className="primary-btn" onClick={save} disabled={!changeCount}>Simpan absensi{changeCount ? ` · ${changeCount}` : ''}</button></div></div>
      {notice && <div className="inline-notice" role="status"><span>i</span>{notice}<button aria-label="Tutup pemberitahuan" onClick={() => setNotice('')}>×</button></div>}
      {visibleStudents.length === 0 ? <div className="master-empty attendance-empty"><div className="empty-mark">⌕</div><h3>{activeStudents.length ? 'Tidak ada siswa yang cocok' : 'Belum ada siswa aktif'}</h3><p>Ubah kata pencarian atau filter untuk menampilkan daftar.</p></div> : <div className="table-wrap attendance-table-wrap"><table className="attendance-table"><thead><tr><th>SISWA</th><th>KELOMPOK</th><th>KEHADIRAN</th><th>CATATAN</th></tr></thead><tbody>{visibleStudents.map(student => { const status = changes[student.id] || dateAttendance[student.id] || 'Belum diisi'; const initial = student.initials || student.name.split(' ').slice(0, 2).map(part => part[0]).join(''); return <tr key={student.id}><td><div className="master-person"><span className={`student-avatar ${student.tone || 'mint'}`}>{initial}</span><span><strong>{student.name}</strong><small>Kode demo {student.id}</small></span></div></td><td>{groups.find(group => group.id === student.groupId)?.name || 'Belum ditetapkan'}</td><td><div className="attendance-status-control"><StatusPill status={status}/><select aria-label={`Status kehadiran ${student.name}`} value={status} onChange={event => changeStatus(student.id, event.target.value)}><option>Belum diisi</option>{attendanceStatuses.map(option => <option key={option}>{option}</option>)}</select></div></td><td className="attendance-note">{status === 'Belum diisi' ? 'Pilih status kehadiran' : status === 'Hadir' ? 'Tercatat di sesi demo' : 'Status dicatat · Demo'}</td></tr> })}</tbody></table></div>}
      <div className="attendance-table-foot"><span>Menampilkan {visibleStudents.length} dari {activeStudents.length} siswa aktif</span><span>Data contoh untuk prototipe</span></div>
    </section>
  </div>
}

function SummaryCard({ label, count, tone }) { return <article className={`attendance-summary-card ${tone}`}><span className="summary-status-dot"/><span className="summary-status-label">{label}</span><strong>{count}</strong><small>siswa ditampilkan</small></article> }
function StatusPill({ status }) { return <span className={`status ${status === 'Belum diisi' ? 'status-pending' : `status-${status.toLowerCase()}`}`}><i/>{status}</span> }
function localDate(date) { return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}` }
