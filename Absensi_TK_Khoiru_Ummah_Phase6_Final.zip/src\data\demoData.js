// Seluruh identitas dan angka berikut adalah ilustrasi untuk prototipe.
export const initialStudents = [
  { id: 'S-001', name: 'Alya Putri', groupId: 'A', status: 'Aktif', attendance: 'Hadir', initials: 'AP', tone: 'rose' },
  { id: 'S-002', name: 'Rafi Akbar', groupId: 'B', status: 'Aktif', attendance: 'Hadir', initials: 'RA', tone: 'blue' },
  { id: 'S-003', name: 'Naila Zahra', groupId: 'A', status: 'Aktif', attendance: 'Izin', initials: 'NZ', tone: 'lilac' },
  { id: 'S-004', name: 'Faris Maulana', groupId: 'B', status: 'Aktif', attendance: 'Sakit', initials: 'FM', tone: 'gold' },
  { id: 'S-005', name: 'Hana Safitri', groupId: 'C', status: 'Aktif', attendance: 'Hadir', initials: 'HS', tone: 'mint' },
  { id: 'S-006', name: 'Zidan Fadhil', groupId: 'C', status: 'Aktif', attendance: 'Hadir', initials: 'ZF', tone: 'blue' },
  { id: 'S-007', name: 'Maryam Aulia', groupId: 'D', status: 'Aktif', attendance: 'Hadir', initials: 'MA', tone: 'lilac' },
  { id: 'S-008', name: 'Ibrahim Naufal', groupId: 'D', status: 'Nonaktif', attendance: 'Alpa', initials: 'IN', tone: 'gold' },
]

export const initialTeachers = [
  { id: 'G-001', name: 'Aisyah Rahmawati', groupId: 'A', status: 'Aktif', initials: 'AR', tone: 'mint' },
  { id: 'G-002', name: 'Zahra Nurfadilah', groupId: 'B', status: 'Aktif', initials: 'ZN', tone: 'lilac' },
  { id: 'G-003', name: 'Maryam Khairunnisa', groupId: 'C', status: 'Aktif', initials: 'MK', tone: 'rose' },
  { id: 'G-004', name: 'Safira Amalia', groupId: 'D', status: 'Aktif', initials: 'SA', tone: 'blue' },
]

export const initialGroups = [
  { id: 'A', name: 'Kelompok A', teacherId: 'G-001', capacity: 12, status: 'Aktif' },
  { id: 'B', name: 'Kelompok B', teacherId: 'G-002', capacity: 12, status: 'Aktif' },
  { id: 'C', name: 'Kelompok C', teacherId: 'G-003', capacity: 12, status: 'Aktif' },
  { id: 'D', name: 'Kelompok D', teacherId: 'G-004', capacity: 12, status: 'Aktif' },
]

export const demoStudents = initialStudents.slice(0, 4).map(student => ({ ...student, group: `Kelompok ${student.groupId}` }))

export const academicYears = ['2025/2026', '2026/2027']
export const semesters = ['Ganjil', 'Genap']

function toLocalDate(date) {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

const recentSchoolDates = []
const dateCursor = new Date()
recentSchoolDates.push(toLocalDate(dateCursor))
while (recentSchoolDates.length < 20) {
  dateCursor.setDate(dateCursor.getDate() - 1)
  if (dateCursor.getDay() !== 0 && dateCursor.getDay() !== 6) recentSchoolDates.push(toLocalDate(dateCursor))
}
const attendancePattern = ['Hadir', 'Hadir', 'Hadir', 'Hadir', 'Hadir', 'Izin', 'Hadir', 'Sakit', 'Hadir', 'Alpa']
export const initialAttendance = recentSchoolDates.flatMap((date, dateIndex) => initialStudents.filter(student => student.status === 'Aktif').map((student, studentIndex) => ({
  id: `${date}-${student.id}`,
  studentId: student.id,
  date,
  status: attendancePattern[(dateIndex + studentIndex) % attendancePattern.length],
  year: '2026/2027',
  semester: 'Ganjil',
})))

export const menuGroups = [
  { label: 'MENU UTAMA', items: [
    { id: 'dashboard', label: 'Dashboard', icon: 'grid' },
    { id: 'siswa', label: 'Data Siswa', icon: 'users' },
    { id: 'guru', label: 'Data Guru', icon: 'teacher' },
    { id: 'kelompok', label: 'Kelompok Kelas', icon: 'layers' },
  ] },
  { label: 'AKADEMIK', items: [
    { id: 'periode', label: 'Tahun Ajaran', icon: 'calendar' },
    { id: 'absensi', label: 'Absensi Harian', icon: 'check' },
    { id: 'rekap', label: 'Rekapitulasi', icon: 'chart' },
    { id: 'narasi', label: 'Narasi Perkembangan', icon: 'note' },
    { id: 'laporan', label: 'Laporan PDF', icon: 'file' },
  ] },
]
