import { useMemo, useState } from 'react'

const configs = {
  siswa: { title: 'Data Siswa', description: 'Kelola daftar siswa dan kelompok belajar.', prefix: 'S', fields: ['name', 'groupId', 'status'], columns: ['Siswa', 'Kelompok', 'Status'] },
  guru: { title: 'Data Guru', description: 'Kelola guru dan kelompok pendamping.', prefix: 'G', fields: ['name', 'groupId', 'status'], columns: ['Guru', 'Kelompok Pendamping', 'Status'] },
  kelompok: { title: 'Kelompok Kelas', description: 'Atur kelompok belajar, guru pendamping, dan kapasitas.', prefix: 'K', fields: ['name', 'teacherId', 'capacity', 'status'], columns: ['Kelompok', 'Guru Pendamping', 'Jumlah Siswa', 'Status'] },
}

function getInitial(type, groups, teachers) {
  if (type === 'kelompok') return { name: '', teacherId: teachers[0]?.id || '', capacity: 12, status: 'Aktif' }
  return { name: '', groupId: groups[0]?.id || '', status: 'Aktif' }
}

export default function MasterDataPage({ type, records, students, teachers, groups, onSave, onDelete }) {
  const config = configs[type]
  const [editing, setEditing] = useState(null)
  const [isOpen, setIsOpen] = useState(false)
  const [form, setForm] = useState(() => getInitial(type, groups, teachers))
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const helper = useMemo(() => ({
    groupName: id => groups.find(group => group.id === id)?.name || 'Belum ditetapkan',
    teacherName: id => teachers.find(teacher => teacher.id === id)?.name || 'Belum ditetapkan',
    groupSize: id => students.filter(student => student.groupId === id).length,
  }), [groups, teachers, students])

  function openEditor(record = null) {
    setEditing(record)
    setForm(record ? { ...record } : getInitial(type, groups, teachers))
    setError('')
    setNotice('')
    setIsOpen(true)
  }

  function updateField(event) {
    const { name, value } = event.target
    setForm(current => ({ ...current, [name]: value }))
  }

  function submit(event) {
    event.preventDefault()
    const name = form.name.trim()
    if (!name) { setError(`Nama ${type === 'siswa' ? 'siswa' : type === 'guru' ? 'guru' : 'kelompok'} wajib diisi.`); return }
    if (type !== 'kelompok' && !form.groupId) { setError('Pilih kelompok belajar terlebih dahulu.'); return }
    if (type === 'kelompok') {
      if (!form.teacherId) { setError('Pilih guru pendamping terlebih dahulu.'); return }
      if (!Number.isInteger(Number(form.capacity)) || Number(form.capacity) < 1) { setError('Kapasitas harus berupa angka minimal 1.'); return }
      const duplicate = groups.some(group => group.id !== editing?.id && group.name.trim().toLowerCase() === name.toLowerCase())
      if (duplicate) { setError('Nama kelompok sudah digunakan.'); return }
    }
    const saved = onSave(type, { ...form, name, ...(type === 'kelompok' ? { capacity: Number(form.capacity) } : {}) }, editing?.id)
    if (saved?.error) { setError(saved.error); return }
    setEditing(null)
    setIsOpen(false)
    setNotice(editing ? 'Perubahan berhasil disimpan di sesi demo.' : 'Data berhasil ditambahkan ke sesi demo.')
  }

  function remove(record) {
    const relation = type === 'kelompok'
      ? helper.groupSize(record.id) > 0 && 'Masih ada siswa di kelompok ini. Pindahkan siswa ke kelompok lain sebelum menghapus.'
      : type === 'guru' && groups.some(group => group.teacherId === record.id) && 'Guru ini masih menjadi pendamping kelompok. Ganti guru pendamping sebelum menghapus.'
    if (relation) { setNotice(relation); return }
    if (!window.confirm(`Hapus ${config.title.toLowerCase()} “${record.name}” dari sesi demo?`)) return
    onDelete(type, record.id)
    setNotice('Data dihapus dari sesi demo.')
  }

  function renderRecord(record) {
    if (type === 'siswa') return <><td><div className="master-person"><span className={`student-avatar ${record.tone || 'mint'}`}>{record.initials || record.name.split(' ').slice(0, 2).map(part => part[0]).join('')}</span><span><strong>{record.name}</strong><small>Kode demo {record.id}</small></span></div></td><td>{helper.groupName(record.groupId)}</td><td><Status status={record.status}/></td></>
    if (type === 'guru') return <><td><div className="master-person"><span className={`student-avatar ${record.tone || 'mint'}`}>{record.initials || record.name.split(' ').slice(0, 2).map(part => part[0]).join('')}</span><span><strong>{record.name}</strong><small>Kode demo {record.id}</small></span></div></td><td>{helper.groupName(record.groupId)}</td><td><Status status={record.status}/></td></>
    return <><td><strong>{record.name}</strong><small className="cell-subtext">Kelompok belajar</small></td><td>{helper.teacherName(record.teacherId)}</td><td>{helper.groupSize(record.id)} <span className="capacity-text">/ {record.capacity} siswa</span></td><td><Status status={record.status}/></td></>
  }

  return <div className="master-page">
    <div className="page-heading"><div><div className="eyebrow green-eyebrow">DATA MASTER · DEMO</div><h1>{config.title}</h1><p>{config.description}</p></div><button className="primary-btn add-record-btn" onClick={() => openEditor()}><span>＋</span> Tambah {type === 'siswa' ? 'Siswa' : type === 'guru' ? 'Guru' : 'Kelompok'}</button></div>
    <div className="master-summary"><div className="summary-symbol">{type === 'siswa' ? '◉' : type === 'guru' ? '✳' : '▦'}</div><div><strong>{records.length}</strong><span>{type === 'siswa' ? 'siswa' : type === 'guru' ? 'guru' : 'kelompok'} dalam data demo</span></div><span className="local-chip"><i/>Lokal sesi ini</span></div>
    {notice && <div className={`inline-notice ${notice.startsWith('Masih') || notice.startsWith('Guru ini') ? 'notice-warn' : ''}`} role="status"><span>i</span>{notice}<button aria-label="Tutup pemberitahuan" onClick={() => setNotice('')}>×</button></div>}
    <section className="panel master-table-panel"><div className="master-table-heading"><div><h2>Daftar {config.title.toLowerCase()}</h2><p>Perubahan hanya tersimpan selama sesi demo.</p></div><span className="record-count">{records.length} data</span></div>
      {records.length === 0 ? <div className="master-empty"><div className="empty-mark">＋</div><h3>Belum ada data</h3><p>Tambahkan data pertama untuk melihatnya di daftar.</p><button className="primary-btn" onClick={() => openEditor()}>Tambah data</button></div> : <div className="table-wrap master-table-wrap"><table className="master-table"><thead><tr>{config.columns.map(column => <th key={column}>{column.toUpperCase()}</th>)}<th className="actions-heading">AKSI</th></tr></thead><tbody>{records.map(record => <tr key={record.id}>{renderRecord(record)}<td><div className="row-actions"><button aria-label={`Ubah ${record.name}`} title="Ubah" onClick={() => openEditor(record)}>Ubah</button><button className="delete-row" aria-label={`Hapus ${record.name}`} title="Hapus" onClick={() => remove(record)}>Hapus</button></div></td></tr>)}</tbody></table></div>}
    </section>
    <div className="master-footnote"><span>ⓘ</span>Data ini bersifat ilustrasi, tidak mewakili data siswa atau guru nyata, dan tidak tersimpan permanen.</div>
    {editing !== null || editing === null && error !== '' ? null : null}
    {isOpen && <div className="modal-backdrop" onMouseDown={event => { if (event.target === event.currentTarget) setIsOpen(false) }}><section className="edit-modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><header><div><span className="eyebrow green-eyebrow">FORM DATA DEMO</span><h2 id="modal-title">{editing ? 'Ubah' : 'Tambah'} {type === 'siswa' ? 'Siswa' : type === 'guru' ? 'Guru' : 'Kelompok'}</h2></div><button type="button" className="modal-close" aria-label="Tutup formulir" onClick={() => setIsOpen(false)}>×</button></header><form onSubmit={submit} noValidate><label htmlFor="record-name">{type === 'siswa' ? 'Nama siswa' : type === 'guru' ? 'Nama guru' : 'Nama kelompok'}<span>*</span></label><input id="record-name" name="name" value={form.name} onChange={updateField} placeholder={type === 'siswa' ? 'Contoh: Alya Putri' : type === 'guru' ? 'Contoh: Aisyah Rahmawati' : 'Contoh: Kelompok A'} autoFocus/>
      {type === 'kelompok' ? <><label htmlFor="teacherId">Guru pendamping<span>*</span></label><select id="teacherId" name="teacherId" value={form.teacherId} onChange={updateField}><option value="">Pilih guru</option>{teachers.map(teacher => <option key={teacher.id} value={teacher.id}>{teacher.name}</option>)}</select><label htmlFor="capacity">Kapasitas siswa<span>*</span></label><input id="capacity" name="capacity" type="number" min="1" value={form.capacity} onChange={updateField}/></> : <><label htmlFor="groupId">Kelompok belajar<span>*</span></label><select id="groupId" name="groupId" value={form.groupId} onChange={updateField}><option value="">Pilih kelompok</option>{groups.map(group => <option key={group.id} value={group.id}>{group.name}</option>)}</select></>}
      <label htmlFor="record-status">Status</label><select id="record-status" name="status" value={form.status} onChange={updateField}><option>Aktif</option><option>Nonaktif</option></select>{error && <p className="form-error" role="alert">{error}</p>}<div className="modal-actions"><button type="button" className="cancel-btn" onClick={() => setIsOpen(false)}>Batal</button><button className="primary-btn" type="submit">Simpan data</button></div><p className="modal-demo-note">Perubahan hanya berlaku pada sesi demo ini.</p></form></section></div>}
  </div>
}

function Status({ status }) { return <span className={`status ${status === 'Aktif' ? 'status-hadir' : 'status-inactive'}`}><i/>{status}</span> }
