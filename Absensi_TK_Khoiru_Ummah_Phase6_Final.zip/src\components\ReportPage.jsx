const statuses = ['Hadir', 'Izin', 'Sakit', 'Alpa']

export default function ReportPage({ students, groups, attendance, year, semester }) {
  const activeStudents = students.filter(student => student.status === 'Aktif')
  const periodAttendance = attendance.filter(item => item.year === year && item.semester === semester && activeStudents.some(student => student.id === item.studentId))
  const rows = activeStudents.map(student => {
    const records = periodAttendance.filter(item => item.studentId === student.id)
    const counts = Object.fromEntries(statuses.map(status => [status, records.filter(record => record.status === status).length]))
    return { student, group: groups.find(group => group.id === student.groupId)?.name || 'Belum ditetapkan', counts, total: records.length, percent: records.length ? Math.round(counts.Hadir / records.length * 100) : 0 }
  })
  const totals = Object.fromEntries(statuses.map(status => [status, periodAttendance.filter(item => item.status === status).length]))
  const total = statuses.reduce((sum, status) => sum + totals[status], 0)
  const percent = total ? Math.round(totals.Hadir / total * 100) : 0
  const dates = [...new Set(periodAttendance.map(item => item.date))].sort()
  const dateRange = dates.length ? `${formatDate(dates[0])} – ${formatDate(dates[dates.length - 1])}` : 'Belum ada tanggal absensi'

  return <div className="report-page"><div className="page-heading report-no-print"><div><div className="eyebrow green-eyebrow">LAPORAN · DATA DEMO</div><h1>Laporan Absensi</h1><p>Pratinjau laporan untuk periode akademik yang dipilih.</p></div><button className="primary-btn report-print-btn" onClick={() => window.print()} disabled={!total}><span>▤</span> Cetak / Simpan sebagai PDF</button></div>
    <div className="report-hint report-no-print"><span>ⓘ</span><p>Tombol membuka dialog cetak browser. Pilih <strong>Save as PDF / Simpan sebagai PDF</strong> pada dialog tersebut untuk membuat PDF di perangkat.</p></div>
    <article className="printable-report"><header className="report-document-header"><div className="report-brand-mark">K</div><div className="report-institution"><strong>Tahfizh Plus Khoiru Ummah</strong><span>Tingkat TK · Bogor Utara</span></div><span className="report-demo-stamp">DATA DEMO</span><div className="report-title-block"><h2>Laporan Rekapitulasi Absensi Siswa</h2><p>Semester {semester} · Tahun Ajaran {year}</p></div></header>
      <div className="report-meta-grid"><div><span>Periode akademik</span><strong>{year} · Semester {semester}</strong></div><div><span>Rentang tanggal data</span><strong>{dateRange}</strong></div><div><span>Jumlah siswa aktif</span><strong>{activeStudents.length} siswa</strong></div><div><span>Jumlah catatan absensi</span><strong>{total} catatan</strong></div></div>
      <section className="report-kpis"><div><span>Hadir</span><strong>{totals.Hadir}</strong></div><div><span>Izin</span><strong>{totals.Izin}</strong></div><div><span>Sakit</span><strong>{totals.Sakit}</strong></div><div><span>Alpa</span><strong>{totals.Alpa}</strong></div><div className="report-percent"><span>Persentase hadir</span><strong>{percent}%</strong></div></section>
      {rows.length === 0 ? <div className="report-empty"><h3>Belum ada siswa aktif</h3><p>Tambahkan data siswa aktif untuk menyusun pratinjau laporan.</p></div> : <div className="table-wrap report-table-wrap"><table className="report-table"><thead><tr><th>NO.</th><th>NAMA SISWA</th><th>KELOMPOK</th><th>HADIR</th><th>IZIN</th><th>SAKIT</th><th>ALPA</th><th>HADIR (%)</th></tr></thead><tbody>{rows.map((row, index) => <tr key={row.student.id}><td>{String(index + 1).padStart(2, '0')}</td><td>{row.student.name}</td><td>{row.group}</td>{statuses.map(status => <td key={status}>{row.counts[status]}</td>)}<td>{row.percent}%</td></tr>)}</tbody><tfoot><tr><th colSpan="3">TOTAL</th>{statuses.map(status => <th key={status}>{totals[status]}</th>)}<th>{percent}%</th></tr></tfoot></table></div>}
      <footer className="report-document-footer"><p>Dokumen pratinjau prototipe · Data ilustrasi lokal, bukan laporan resmi.</p><span>Dibuat {new Intl.DateTimeFormat('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }).format(new Date())}</span></footer>
    </article>
    {!total && <div className="report-empty report-no-print"><h3>Belum ada absensi untuk periode ini</h3><p>Catat absensi pada periode yang sama untuk menampilkan laporan.</p></div>}
  </div>
}

function formatDate(date) { return new Intl.DateTimeFormat('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }).format(new Date(`${date}T12:00:00`)) }
