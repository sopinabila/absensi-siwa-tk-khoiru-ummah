# SOT — Sistem Informasi Absensi Siswa
**Tahfizh Plus Khoiru Ummah Tingkat TK Bogor Utara**

Paket ini berisi dokumen fase perancangan (SOT), kontrak awal agen, dan prompt eksekusi awal. Implementasi aplikasi belum dijalankan; lanjut ke tahap implementasi setelah persetujuan pengguna.

## Isi paket
- `PRD.md` — kebutuhan produk dan ruang lingkup.
- `UI-GUIDELINE.md` — sistem visual dan pola antarmuka.
- `IMPLEMENTATION_PLAN.md` — rencana implementasi bertahap.
- `AGENTS.md` — kontrak kerja agen untuk menjaga batasan proyek.
- `PROMPT_EXECUTION.md` — prompt untuk memulai implementasi setelah disetujui.
- `preview/index.html` — preview ringkas isi dokumen dalam satu halaman.

## Batasan
- Fokus front-end menggunakan React + Vite.
- Node.js digunakan sebagai runtime/perkakas pengembangan; backend/API nyata tidak termasuk fase ini.
- Data dummy lokal, tanpa database atau autentikasi produksi.
- Laporan PDF pada prototipe dapat berupa tampilan/aksi demo atau ekspor sisi klien jika disetujui saat implementasi.
